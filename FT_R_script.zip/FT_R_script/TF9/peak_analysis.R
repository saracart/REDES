## Determinación dianas de transcripción para el FT

## Autor: Sara Cartan Moya y Jorge Domínguez Barragán
## Fecha: November 2019

##Setting woring directory


## Loading arguments

library(ChIPseeker)
library(TxDb.Athaliana.BioMart.plantsmart28)
txdb <- TxDb.Athaliana.BioMart.plantsmart28

library(clusterProfiler)
library(org.At.tair.db)

library("pathview")


## Reading peak file

peaks <- readPeakFile(peakfile = "peaks_1_peaks.narrowPeak" ,header=FALSE)
head(peaks)
dim(peaks)

## Defining the region that is considered as a promoter. 
## Normaly de region contaions a 1000 pb upstream and downstream the TSS

promoter <- getPromoters(TxDb=txdb, 
                         upstream=-1000, 
                         downstream=1000)


## Checking the number of genes from de A.Thaliana genome. It should have 33602 genes

genes <- as.data.frame(genes(txdb))
genes_names <- genes$gene_id
length(genes_names)


## Annotating peaks

peakanno <- annotatePeak(peak = peaks, 
                         tssRegion=c(-1000, 1000),
                         TxDb=txdb)

## Binding sites in specific regions of the genome

plotAnnoPie(peakanno)
vennpie(peakanno)

plotAnnoBar(peakanno)

## Distribution of genomic loci relative to TSS

plotDistToTSS(peakanno,
              title="Distribution of genomic loci relative to TSS",
              ylab = "Genomic Loci (%) (5' -> 3')")


## Converting annotation to data frame and writing a table with target genes

annotation_dataframe <- as.data.frame(peakanno)
target_genes <- annotation_dataframe$geneId[annotation_dataframe$annotation == "Promoter"]

write(x = target_genes, file="AT5G24470.txt")

##GO TERMS ENRICHMENT

##Reading the target genes

gene.set <- read.table(file = "target_genes.txt", header = F, as.is = T)[[1]]
length(gene.set)

