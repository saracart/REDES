## Determinación dianas de transcripción para el FT

## Autor: Sara Cartan Moya y Jorge Domínguez Barragán
## Fecha: November 2019

##Setting woring directory


## Loading arguments

library(ChIPseeker)
library(TxDb.Athaliana.BioMart.plantsmart28)
txdb <- TxDb.Athaliana.BioMart.plantsmart28

library(clusterProfiler)
library(org.At.tair.db)

library("pathview")


## Reading peak file

peaks1 <- readPeakFile(peakfile = "peaks_1_peaks.narrowPeak",header=FALSE)
head(peaks1)
peaks2 <- readPeakFile(peakfile = "peaks_2_peaks.narrowPeak",header=FALSE)
head(peaks2)
peaks3 <- readPeakFile(peakfile = "peaks_3_peaks.narrowPeak",header=FALSE)
head(peaks3)
peaks4 <- readPeakFile(peakfile = "peaks_4_peaks.narrowPeak",header=FALSE)
head(peaks4)

peaks <- intersect(intersect(intersect(peaks1,peaks2), peaks3), peaks4)

head(peaks)
dim(peaks)

## Defining the region that is considered as a promoter. 
## Normaly de region contaions a 1000 pb upstream and downstream the TSS

promoter <- getPromoters(TxDb=txdb, 
                         upstream=-1000, 
                         downstream=1000)


## Checking the number of genes from de A.Thaliana genome. It should have 33602 genes

genes <- as.data.frame(genes(txdb))
genes_names <- genes$gene_id
length(genes_names)


## Annotating peaks

peakanno <- annotatePeak(peak = peaks, 
                         tssRegion=c(-1000, 1000),
                         TxDb=txdb)

## Binding sites in specific regions of the genome

plotAnnoPie(peakanno)
vennpie(peakanno)

plotAnnoBar(peakanno)

## Distribution of genomic loci relative to TSS

plotDistToTSS(peakanno,
              title="Distribution of genomic loci relative to TSS",
              ylab = "Genomic Loci (%) (5' -> 3')")


## Converting annotation to data frame and writing a table with target genes

annotation_dataframe <- as.data.frame(peakanno)
target_genes <- annotation_dataframe$geneId[annotation_dataframe$annotation == "Promoter"]

write(x = target_genes, file="target_genes_3.txt")

##GO TERMS ENRICHMENT

##Reading the target genes

gene.set <- read.table(file = "target_genes.txt", header = F, as.is = T)[[1]]
length(gene.set)

## GO Enrichment analysis of a gene set

ego <- enrichGO(gene = gene.set, OrgDb = org.At.tair.db, ont = "BP", pvalueCutoff = 0.05, qvalueCutoff = 0.01, universe = genes_names, keyType = "TAIR")
ego.res <- as.data.frame(ego)
head(ego.res)

dotplot(ego)
barplot(ego, showCategory=13 )
emapplot(ego, showCategory = 13)

## KEGG enrichment


kk <- enrichKEGG(gene = gene.set, organism = "ath", universe = genes_names)
kk
kk.res <- as.data.frame(kk)
head(kk.res)

kk.ID<-kk.res$ID

my.universe <- rep(0,length(genes_names))
names(my.universe) <- genes_names
my.universe[gene.set] <- 1
my.universe




pathway.res <- pathview(gene.data = my.universe, pathway.id = kk.ID, species = "ath", gene.idtype = "TAIR")
